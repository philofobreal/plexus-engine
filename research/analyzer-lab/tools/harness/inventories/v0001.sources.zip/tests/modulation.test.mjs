import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import vm from 'node:vm';
import test from 'node:test';
import assert from 'node:assert/strict';
import ts from 'typescript';

function loadVisualTuningModule() {
  const source = readFileSync(join(process.cwd(), 'src/config/visualTuning.ts'), 'utf8');
  const transpiled = ts.transpileModule(source, {
    compilerOptions: {
      module: ts.ModuleKind.CommonJS,
      target: ts.ScriptTarget.ES2022
    }
  }).outputText;
  const context = vm.createContext({
    exports: {},
    require(request) {
      if (request === './featureFlags') return { featureFlags: { heroEffect: false } };
      throw new Error(`Unsupported import in test loader: ${request}`);
    },
    Math,
    Number
  });
  vm.runInContext(transpiled, context);
  return context.exports;
}

test('modulation bus keeps all outputs in the normalized range', () => {
  const { computeModulationBus, defaultVisualTuning } = loadVisualTuningModule();
  const frame = { e: 3, densityProj: 2, melodyProj: 0.4, fxProj: 1.8, state: 'HIGH', eRatio: 1.5 };
  const features = { melody: 1.4, vocal: 1.2, fx: 2, density: 1.7, brightness: 1.3, tension: 1.6 };
  const modulation = computeModulationBus(frame, features, 1.8, 1.5, { ...defaultVisualTuning, audioSensitivity: 3 });

  for (const value of Object.values(modulation)) {
    assert.ok(value >= 0);
    assert.ok(value <= 1);
  }
});

test('audioSensitivity linearly scales modulation values until clamped', () => {
  const { computeModulationBus, defaultVisualTuning } = loadVisualTuningModule();
  const frame = { e: 0.1, densityProj: 0.1, melodyProj: 0.1, fxProj: 0.1, state: 'HIGH', eRatio: 0.1 };
  const features = { melody: 0.1, vocal: 0.1, fx: 0.1, density: 0.1, brightness: 0.1, tension: 0.1 };
  const half = computeModulationBus(frame, features, 0.1, 0.1, { ...defaultVisualTuning, audioSensitivity: 0.5 });
  const normal = computeModulationBus(frame, features, 0.1, 0.1, { ...defaultVisualTuning, audioSensitivity: 1 });
  const double = computeModulationBus(frame, features, 0.1, 0.1, { ...defaultVisualTuning, audioSensitivity: 2 });

  for (const key of Object.keys(normal)) {
    assert.equal(Number(normal[key].toFixed(6)), Number((half[key] * 2).toFixed(6)));
    assert.equal(Number(double[key].toFixed(6)), Number((normal[key] * 2).toFixed(6)));
  }
});

test('writeModulationBus mutates and returns the caller-owned modulation object', () => {
  const { computeModulationBus, writeModulationBus, defaultVisualTuning } = loadVisualTuningModule();
  const frame = { e: 0.7, densityProj: 0.5, melodyProj: 0.25, fxProj: 0.9, state: 'HIGH', eRatio: 1.1 };
  const features = { melody: 0.8, vocal: 0.4, fx: 0.7, density: 0.6, brightness: 0.9, tension: 0.5 };
  const target = {
    kineticTension: -1,
    densityDrive: -1,
    spectralChaos: -1,
    rhythmicImpulse: -1,
    macroMomentum: -1
  };
  const expected = computeModulationBus(frame, features, 0.3, 0.2, defaultVisualTuning);

  const returned = writeModulationBus(target, frame, features, 0.3, 0.2, defaultVisualTuning);

  assert.equal(returned, target);
  assert.deepEqual({ ...target }, { ...expected });
});

test('low-frequency bus preserves bands, applies sensitivity once and never synthesizes beat impulses', () => {
  const { computeModulationBus, defaultVisualTuning } = loadVisualTuningModule();
  const frame = Object.freeze({ e: 0, eRatio: 0, densityProj: 0, fxProj: 0,
    subEnergy: 0.4, bassEnergy: 0.2, subFlux: 0.1, bassFlux: 0.3 });
  const features = { melody: 0, vocal: 0, fx: 0, density: 0, brightness: 0, tension: 0 };
  const normal = computeModulationBus(frame, features, 0, 0, { ...defaultVisualTuning, audioSensitivity: 1 });
  const half = computeModulationBus(frame, features, 0, 0, { ...defaultVisualTuning, audioSensitivity: 0.5 });
  for (const key of ['subEnergy','bassEnergy','subFlux','bassFlux']) {
    assert.equal(normal[key], frame[key]); assert.equal(half[key], frame[key] * 0.5);
  }
  assert.equal(normal.rhythmicImpulse, 0);
  assert.ok(normal.macroMomentum > 0); assert.ok(normal.kineticTension > 0);
  const corrupt = computeModulationBus({ ...frame, subEnergy: NaN, bassFlux: Infinity }, features, 0, 0, defaultVisualTuning);
  assert.ok(Object.values(corrupt).every(Number.isFinite));
  const mute = computeModulationBus(frame, features, 0, 0, { ...defaultVisualTuning, audioSensitivity: 0 });
  assert.ok(Object.values(mute).every(v => v === 0));
});

test('visual tuning normalization maps legacy particleBassTurn payloads to particleActivityTurn', () => {
  const { normalizeVisualTuningConfig, defaultVisualTuning } = loadVisualTuningModule();

  const legacy = normalizeVisualTuningConfig({ visualTuning: { particleBassTurn: 0.73 } });
  const canonical = normalizeVisualTuningConfig({
    visualTuning: {
      particleBassTurn: 0.73,
      particleActivityTurn: 0.42
    }
  });

  assert.equal(legacy.particleActivityTurn, 0.73);
  assert.equal(canonical.particleActivityTurn, 0.42);
  assert.equal(defaultVisualTuning.particleActivityTurn, 0.1);
});

test('visual tuning normalization preserves current values for missing preset keys', () => {
  const { normalizeVisualTuningConfig, defaultVisualTuning } = loadVisualTuningModule();
  const current = {
    ...defaultVisualTuning,
    morphDurationSec: 12,
    morphCurveValue: 2,
    buildupIntensity: 1.6,
    audioSensitivity: 2.4
  };

  const normalized = normalizeVisualTuningConfig({ visualTuning: { audioSensitivity: 0.8 } }, current);

  assert.equal(normalized.audioSensitivity, 0.8);
  assert.equal(normalized.morphDurationSec, 12);
  assert.equal(normalized.morphCurveValue, 2);
  assert.equal(normalized.buildupIntensity, 1.6);
});

test('legacy presets default new wormhole controls without breaking partial loads', () => {
  const { normalizeVisualTuningConfig } = loadVisualTuningModule();
  const normalized = normalizeVisualTuningConfig({ visualTuning: { wormholeSpeed: 3.25 } });

  assert.equal(normalized.wormholeSpeed, 3.25);
  assert.equal(normalized.wormholeEmissionMode, 0);
  assert.equal(normalized.wormholeJitter, 0);
});

test('hueToRgbInto matches hueToRgb, returns the provided tuple, and normalizes hue', () => {
  const { hueToRgb, hueToRgbInto } = loadVisualTuningModule();
  const target = [0, 0, 0];

  const returned = hueToRgbInto(target, -30);

  assert.equal(returned, target);
  assert.deepEqual(Array.from(target), Array.from(hueToRgb(-30)));
  assert.deepEqual(Array.from(target), Array.from(hueToRgb(330)));

  hueToRgbInto(target, 390, 80, 45);
  assert.deepEqual(Array.from(target), Array.from(hueToRgb(30, 80, 45)));
});

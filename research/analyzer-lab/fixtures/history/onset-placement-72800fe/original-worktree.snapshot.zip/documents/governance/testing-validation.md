﻿# Testing And Validation

This document extends `../../AGENTS.md`. If there is a conflict, `AGENTS.md` is authoritative.

## Cumulative regression and research retention

The project retains every previously active regression alongside new tests. `npm test` recursively discovers active `tests/**/*.test.mjs`; the analyzer lab runs its entire Python test tree. The cumulative harness records discovered tests, helpers/fixtures, source identities, commands, outcomes and omissions. Historical mirrors in `documents/tests/` remain source archives: verified aliases refer to canonical tests, and detached unmatched snapshots are explicitly unexecuted, never claimed as coverage. Do not execute detached copies with invented import context.

Protected predecessor sources and results are immutable historical evidence. A legitimate replacement or snapshot change requires a reviewed reason, predecessor/replacement identities and retention of the predecessor; a better new score must not rewrite the old experiment. Known baseline failures remain failures and are separately classified only when names and assertion evidence match. New failures block acceptance regardless of average scores.

Reusable Python/JavaScript programs, generators, diagnostics, evaluators and reproduction tools belong in versioned research source, with purpose, input/output contract, invocation and provenance. Keep generated audio, models, environments, large logs and temporary checkouts outside source control; retain compact result summaries and artifact hashes/locations. Inert historical script snapshots are evidence, not automatically runnable current tools. No helper may overwrite protected fixtures/results as an incidental step of testing.

See [analyzer development method](../../research/analyzer-lab/docs/ANALYZER-DEVELOPMENT-METHOD.md) for musical task definitions and experiment/promotion gates. Retention does not establish musical independence, library truth or physical XR precision.

## Validation Matrix

Documentation-only governance changes:

- Check all referenced files exist.
- Check `CLAUDE.md` explicitly inherits from `AGENTS.md`.
- Check supporting docs do not contradict `AGENTS.md`.
- Check policy is not duplicated wholesale across files.

Build-level changes:

- Inspect the available runtime/package manager and the scripts in `package.json`, then start with `npm run build` and `npm test` when those scripts are declared.
- For targeted tests, use `node --test <test-file>` with explicit files.
- If a required script is absent or broken, use `npx`, a local `node_modules/.bin` executable, or a local package entrypoint. For example, when a bundled Node executable is the available Node runtime:

```powershell
& '<bundled-node>\node.exe' .\node_modules\typescript\bin\tsc
& '<bundled-node>\node.exe' .\node_modules\vite\bin\vite.js build
```

- A local-entrypoint fallback for the full test suite is:

```powershell
& '<bundled-node>\node.exe' --test tests\*.test.mjs tests\ui\*.test.mjs
```

- A targeted local-entrypoint fallback uses explicit files, for example:

```powershell
& '<bundled-node>\node.exe' --test tests\ui-interaction.test.mjs tests\timeline-ui.test.mjs tests\contracts.test.mjs
```

- Do not install a dependency only to enable validation. Do not use a Bun-first strategy; use Bun only if it is the only available, working project runner.
- Report the exact commands run and why every runtime or package-manager fallback was used.
- For renderer, UI, or performance-contract changes, include TypeScript checking, a production Vite build, Node tests, and `git diff --check` in the handoff whenever practical. A Vite chunk-size warning is informational unless the task is specifically about bundle splitting or load performance.

Audio playback changes:

- Validate play, pause, resume, seek while playing, seek while paused, rapid seek, load new file during playback, and natural end.
- Confirm old source nodes are stopped, disconnected, and not allowed to fire stale `onended` behavior.

Worker changes:

- Validate success, failure, cancellation, superseded load, request-id mismatch, and deterministic output for the same fixture.
- Validate worker termination in every path.

Analyzer timing changes (tempo / beat / grid):

- The analyzer timing subsystem has two layers of fixtures, kept distinct on purpose:
  - **Regression (golden master)**: `tests/analyzer-golden.test.mjs` compares against snapshots in `tests/fixtures/golden/` with tolerances (+/-15ms on time arrays, 1e-4 scalars, exact counts). These only encode "what the algorithm currently does".
  - **Musical correctness (verification)**: `tests/analyzer-verification.test.mjs` asserts the engine against KNOWN ground truth (tempo metric-match, beat precision, bar precision) for fixtures spanning 70-176 BPM and house/techno/trance/dnb/breakbeat/sparse/breakdown. `strictTempo` fixtures (e.g. drum & bass) must lock the actual beat rate — a half/double read is a failure.
  - Focused suites: `analyzer-metric-ambiguity` (half/double), `analyzer-timing-confidence` (unified confidence), `analyzer-timing-edgecases` (silence, click track, tempo transition, breakdown extrapolation vs. suppressed visual events), `analyzer-dsp` (TempoEstimator / BeatTracker / onset envelope units).
  - `analyzer-local-tempo` covers fixed-window recurring-flux estimation: section loudness versus repetition, long gaps and shifted phases, outliers, insufficient attacks, ambiguous tempos, invalid clocks/options, final-window evidence and raw-audio house/DnB/slow-floor integration. Keep strict DnB and slow-pulse assertions alongside estimator-level metric-family checks. Short golden clips alone cannot validate duration-independent pooling. Profile long envelopes separately from FFT/decode; do not make wall-clock timing a flaky test assertion.
- The current `update-golden-masters` package script is Bun-dependent. Migrating it to a Node-compatible entrypoint is a separate task; in an environment without a working Bun runtime, do not attempt to run or emulate it automatically. Snapshot generation intentionally OVERWRITES baselines and must run ONLY when a timing change is a deliberate, reviewed improvement. Inspect the git diff before committing regenerated snapshots.
- `tests/fixtures/analyzer/headless-baseline.summary.json` is the exact-match contract baseline for the synthetic SaaS/VST fixture; regenerate it deliberately when the algorithm legitimately changes, never to silence an unexplained drift.
- Benchmark/fixture framework changes and timing-algorithm changes are ideally landed as separate commits so a baseline diff makes clear whether the algorithm actually improved.

State/event changes:

- Sub/bass changes require fixed-Hz separation across sample rates, relative mixed-band levels,
  sustained tones versus positive change, ramps, mixed kick/bass, silence/DC/near-silence,
  outliers, short/malformed input and deterministic/no-input-mutation checks. Keep tempo/event
  baselines separate. Verify schema/defaults, load/reset and preview/seek/export scalar parity,
  sensitivity applied once, and no fabricated beat impulse. Measure offline cost outside CI
  timing assertions; document long-window temporal spreading and actual render smoke evidence.

- Validate ordered transitions for load, analysis complete, play, pause, seek, stop, and end.
- Validate beat event index reset and no duplicate event playback after seek.

Visual changes:

- Run a render smoke check in a browser when practical.
- Confirm canvas is nonblank, particles remain bounded, shockwaves expire, and the draw loop does not allocate unbounded persistent objects.
- For visual identity or style-registry changes, run the browser-free deterministic style harness (`node --test tests/styles-deterministic.test.mjs`) or explain why it was not applicable.
- If in-app browser automation cannot reach a transient local dev server, verify server startup and HTTP status with a short-lived shell job, then report browser smoke as not completed.

Visual identity transition changes:

- Run `node --test tests/visual-mode-transition.test.mjs tests/wormhole-depth-integrity.test.mjs tests/wormhole-lifecycle.test.mjs` plus `tests/contracts.test.mjs` and `tests/styles-deterministic.test.mjs` when the shared identity contract changes.
- `computeCrossfadeAlpha` coverage must pin start, midpoint, completion, and backward-song-time behavior. Transition request coverage must pin synchronous logical switching, no paused dual render, live/export clock anchoring, and the `0.1..4.0` duration clamp.
- Compositor regressions must assert two persistent targets, per-active-frame clearing, `source-over`, and the true `A * (1 - alpha) + B * alpha` weights. Additive `lighter` blending is forbidden.
- Controller regressions must assert that compositing runs only during an active transition, completion returns to the direct steady-state path, and `State.visualMode` has one runtime writer.
- Transition ownership coverage must keep record creation/replacement in `requestVisualModeChange()` and completion cleanup in the renderer-owned controller. Effect modules must not own compositing or transition state.
- Shared simulation gating must prove that one participant advances shared particle/shockwave pools exactly once. Incoming normally owns advancement; when it does not use the shared pool, eligible outgoing owns it and the other participant receives `advanceSharedSimulation: false`.
- Wormhole determinism coverage must include immutable depth-phase uniformity under a moving horizon, authored coherence determinism, repeated seeks without accumulated density damage, identical tunnel and curved-galaxy geometry after different histories, and automation-transition re-arming after backward seek.

Renderer post FX changes (ADR-007):

- Run `node --test tests/postfx-fragmentation.test.mjs` plus `tests/visual-mode-transition.test.mjs`
  and `tests/contracts.test.mjs` when the post seam, the chain contract, or the renderer draw order
  changes.
- Coverage must pin: full bypass at zero effect strength and zero master amount; the explicit
  `performanceMode` and paused/stopped bypasses ahead of any target resolution or allocation; lazy
  single buffer allocation with resize only on a real dimension change; identical decisions for the
  live and export clock at the same song time; determinism across repeated and revisited song times;
  fragment bounds and the cleared-rect coverage contract that protects transparent/chroma output;
  absence of runtime randomness in the post path; and exactly one post seam in the renderer, placed
  after the finished identity frame.
- Adding a post effect requires proving that the chain still runs once per frame on the final
  composite and that shared particle/shockwave simulation still advances exactly once per frame.

Semantic dramaturgy layer changes (ADR-003):

- **Semantic Determinism Test (required).** Identical `TrackAnalysis` must produce identical narrative, intent, Visual Score, and choreography plans, independent of the selected style. Assert this with `node --test tests/semantics.test.mjs tests/visual-score-dsl.test.mjs`.
- Confirm the Visual Score survives a JSON stringify/parse round trip, every adjacent motif has a transition, fast BPM uses coarse subdivisions, slow BPM retains internal variation, and low timing confidence falls back to phrase/section timing.
- Confirm cascade, grow, and shrink produce measurably different resolved tuning outputs through propagated motif intensity/density/motion fields, and long transitions contain more than three progress samples.
- Confirm the layer stays headless: no p5, DOM, `src/state/`, `src/visuals/`, `src/ui/`, or `src/audio/` imports under `src/semantics/` (guarded by a test).
- Confirm `SemanticResolver` keeps every resolved parameter within `visualTuningControls` min/max bounds for all styles, including saturated/empty choreography input.
- Confirm channel separation: the resolver writes only `State.targetTuning`; the modulation bus and `directorOutput` remain FSM-owned.
- Confirm `featureFlags.semanticResolver` defaults off and that the legacy `performancePlan` path is unchanged when off (run `node --test tests/styles-deterministic.test.mjs` and `tests/contracts.test.mjs`).

UI changes:

- Validate disabled/enabled states, dashboard text, BPM badge, seek bar, time display, and responsive layout.
- For dynamically constrained range inputs, test model-to-control limits below the default,
  fractional endpoints, exhausted ranges and re-enabling. Browser checks must exercise native
  dragging and keyboard endpoints: a mocked input does not reproduce HTML step rounding.
  For proportional timeline scaling, also test bounds above former UI caps, unequal transition
  lengths, the final track boundary, changes to the limiting pair and non-destructive projection.
  Verify accepted limits agree across controller, view cache, storage and undo/redo snapshots;
  a model clamp caused by an edit belongs in that edit's history entry.
  Include a real-generator fixture with near-coincident scene boundaries: clean hand-built
  plans alone cannot detect a generation floor that contradicts the spacing/clamping policy.
- For MVP history/workspace changes, apply the [session-persistence evidence requirements](session-persistence.md#required-evidence),
  including same-file reselection after reload, token consumption, storage failures and no audio persistence.
  Use detailed multi-point journeys for the 300-command storage test: tiny one-point fixtures
  miss repeated-plan payload growth. Cover capture failure followed by retry, actionable modal
  errors, lossless encoded round trips and hostile delta expansion before allocation.

XR rhythm game host changes (ADR-009):

- Run `node --test tests/gameplay-purity.test.mjs tests/rhythm-chart.test.mjs tests/rhythm-judge.test.mjs tests/rhythm-session.test.mjs tests/rhythm-scoring.test.mjs tests/xr-spatial.test.mjs tests/xr-performance.test.mjs tests/xr-audio-integration.test.mjs tests/xr-choreography.test.mjs tests/xr-whole-track-variation.test.mjs tests/xr-wormhole.test.mjs tests/xr-runway.test.mjs tests/xr-track-path.test.mjs tests/xr-command-drawer.test.mjs tests/xr-generation-settings.test.mjs tests/xr-section-callout.test.mjs tests/xr-controller-regeneration.test.mjs tests/xr-edge-cases.test.mjs tests/xr-background-settings.test.mjs tests/xr-wormhole-worker.test.mjs tests/xr-wormhole-continuity.test.mjs tests/xr-settings.test.mjs tests/xr-play-profile.test.mjs tests/xr-score-overview.test.mjs tests/xr-section-gates.test.mjs tests/xr-play-space.test.mjs tests/xr-ultra.test.mjs tests/xr-menu.test.mjs tests/xr-note-design.test.mjs tests/xr-background-diagnostics.test.mjs tests/xr-gpu-material.test.mjs tests/wormhole-depth-layers.test.mjs tests/xr-slice-gpu.test.mjs tests/xr-note-gpu.test.mjs tests/xr-gpu-lines.test.mjs tests/xr-wormhole-spatial.test.mjs tests/xr-wormhole-spatial-field.test.mjs tests/xr-webgl-backend.test.mjs`.
- Default chart output is pinned by `tests/fixtures/xr-chart-default-golden.json` (captured before generation settings existed); only an intentional default-behaviour change may regenerate it, with the reason recorded.
- Changes to the shared MVP Wormhole path (`src/config/` gain resolution, `applyMvpWormholePreset`, injected `WormholeRenderState`) also run `tests/mvp-macro-tuning-mapper.test.mjs`, `tests/mvp-async-lifecycle.test.mjs`, `tests/semantics-integration.test.mjs` and the wormhole determinism/lifecycle suites, because the MVP consumes the same code.
- `AudioEngine` host-option changes follow the audio playback matrix above and must keep dashboard/MVP defaults unchanged.
- Desktop, browser or mocked-device results never substitute for physical Quest acceptance; record headset runs in `../audits/xr-rhythm-game-quest3-manual-test.md`.

Automation publication changes (ADR-005 cue-evidenced gate):

- Run `node --test tests/automation-cue-alignment.test.mjs tests/dramaturgy.test.mjs tests/automation.test.mjs tests/visual-os.test.mjs`.
- The gate affects dashboard, MVP and XR plans. Pin omissions explicitly; do not add cues, novelty peaks or boundary candidates to a fixture only to keep an expected point.

Documentation and governance changes:

- Verify every referenced governance file exists.
- Verify `AGENTS.md` remains the only canonical root policy and `CLAUDE.md` remains a thin inheritance shim.
- Prefer adding platform-specific operating rules to `platform-operations.md` instead of scattering shell/runtime advice across subsystem docs.

Diff export and handoff checks:

- When preparing a PR summary, final handoff, or large-change review, consider running `.\diff_export.ps1 -BaseBranch <branch>` from `plexus-engine/`.
- If `branch_pr_snapshot.md` is generated, verify it is not staged for commit and use it only as a local review artifact.
- Report whether the snapshot was generated, skipped as unnecessary, or blocked by network/execution policy.

## Reporting Requirements

Every final report must state:

- Validation commands run.
- Manual checks performed.
- Checks not run and why.
- Residual risk.
- Every runtime or package-manager fallback used, with the reason and exact command.
- Whether browser smoke validation was full browser automation, HTTP-only, or skipped.
- Whether `diff_export.ps1` was used when the task involved PR-style review, handoff, or broad change summarization.

## Minimum Gate For Risky Areas

Changes touching `src/audio`, `src/audio/*.worker.ts`, `src/state`, event indexes, or playback time require build validation and targeted regression notes.

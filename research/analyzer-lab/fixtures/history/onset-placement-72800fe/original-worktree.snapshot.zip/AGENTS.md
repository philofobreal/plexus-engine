# Plexus Engine Agent Governance

`AGENTS.md` is the canonical source of truth for every agent, subagent, and automation working in this repository. If another local instruction file conflicts with this file, follow this file and report the conflict.

The active project root is `plexus-engine/`. The sibling `v0.1/` and `v0.2/` directories are historical product/spec references, not governance sources.

## Mission

Plexus Engine is a modular, browser-based, audio-reactive visual engine and performance instrument designed specifically for electronic musicians, producers, and live act performers who want instant, highly-customizable generative visuals derived from their own tracks. Unlike classic VJ clip-launchers or generic streamer overlays, Plexus Engine is built on offline track-structure awareness (sections, buildup confidence, cues, patterns) and a normalized modulation bus, translating zene-dramaturgia directly into generative GPU-accelerated motion.

All modifications must preserve deterministic playback, offline analysis, safe worker communication, stable module ownership, and predictable rendering performance.

Optimize all work for:

- Architectural consistency.
- Deterministic event and state handling.
- Safe parallel execution by agents.
- Long-term maintainability during large refactors.
- Minimal hidden coupling between audio, worker, state, UI, and renderer modules.

## Governance Documents

These documents extend this file and must not override it:

- [Architecture Contract](documents/governance/architecture-contract.md)
- [Subagent Orchestration](documents/governance/subagent-orchestration.md)
- [Realtime Audio Safety](documents/governance/realtime-audio-safety.md)
- [Worker Communication](documents/governance/worker-communication.md)
- [Testing and Validation](documents/governance/testing-validation.md)
- [Platform Operations](documents/governance/platform-operations.md)
- [Anti-Patterns](documents/governance/anti-patterns.md)
- [Session Persistence](documents/governance/session-persistence.md)

`CLAUDE.md` is a compatibility shim only. It must explicitly inherit from this file and must not accumulate independent policy.

## Graphify-Assisted Repository Navigation

When `graphify-out/graph.json` is available, use Graphify as a scoped
repository-navigation aid before broad source exploration.

- Start with `graphify explain`, `graphify path`, or `graphify affected`
  using exact symbols.
- Prefer `graphify affected "<symbol>" --depth 2` for change-impact discovery.
- Prefer `graphify path "<source>" "<target>"` for a specific dependency or
  data-flow hypothesis.
- Use broad natural-language `graphify query` only for initial discovery.
  Keep its context budget bounded and narrow the relation type when practical.
- Treat Graphify output as navigation evidence, not architectural truth.
- Verify every relationship used for planning or implementation against the
  referenced source files, tests, and applicable governance documents.
- Do not infer ownership from community membership, node centrality, or an
  unverified `INFERRED` or `AMBIGUOUS` edge.
- Ignore generic-name connections such as `clamp()`, `sleep()`, `index.ts`,
  or `write*()` unless source inspection proves the relationship.
- If the graph is missing, stale, contradictory, or noisy, fall back to
  targeted `rg`, direct source inspection, and the canonical governance files.
- Do not start deep extraction, invoke an LLM backend, install Graphify hooks,
  or rebuild the semantic corpus unless the user explicitly requests it.

## Module Ownership

- `src/main.ts` composes the dashboard; `src/ui/mvp/main.ts` is the MVP composition entrypoint with the same startup responsibility (see ADR-008). `src/xr/main.ts` is a third, independent composition entrypoint for the `/xr/` WebXR rhythm-game host (see ADR-009); it wires its own `AudioEngine` instance and never shares a runtime with the other two. Only these entrypoints create and wire audio, UI and renderer subsystems.
- `src/gameplay/` owns pure, renderer-independent rhythm-game domain logic (chart construction, judging, session state) for the `/xr/` host. It must not import Three.js, WebXR, DOM, `AudioEngine`, or `src/state/`; it may import shared `src/types/` contracts. `src/xr/` owns all Three.js/WebXR runtime, scene, input, and performance-policy code and must not implement or extend `VisualRendererBackend`. See [ADR-009](documents/adr/ADR-009-xr-rhythm-game-host.md).
- `src/audio/` owns file decode, `AudioContext`, playback lifecycle, source nodes, timing, and worker invocation.
- `src/analyzer/` owns deterministic offline DSP, grid alignment, section analysis, dramaturgy, headless `analyzeAudio()`, and canonical analysis normalization. It must remain environment-independent and must not import Worker, DOM, p5, UI, renderer, playback, or shared mutable runtime state.
- `src/audio/analyzer.worker.ts` is a thin Web Worker adapter around `src/analyzer/analyzeAudio()`. It owns only request destructuring, progress forwarding, success posting, and error message formatting.
- `src/state/` owns the shared state shape and documented mutation semantics.
- `src/visuals/` owns p5 rendering, particle lifecycle, shockwaves, and visual consumption of precomputed events.
- `src/ui/` owns DOM binding, controls, dashboard projection, and user-facing state display.
- `src/types/` owns shared contracts and must remain dependency-light.
- `src/automation/` owns offline performance-plan generation (legacy generator and the ADR-005 Visual OS pipeline), the cue-evidenced publication gate, plan editing/transfer helpers, and host-shared preset-merge/runtime helpers. It returns plans and never writes `State`; see [ADR-005](documents/adr/ADR-005-visual-os-style-system.md).
- `src/config/` owns tuning-control metadata, feature flags, identity tuning ownership, and the shared macro/Advanced gain resolution used by the MVP and the XR Wormhole background. It holds pure helpers and constants, not runtime state.
- `src/semantics/` owns the pure, offline, deterministic Visual Score DSL pipeline. It must follow [ADR-003](documents/adr/ADR-003-semantic-layer-boundary.md), must not import runtime state, DOM, p5, audio, UI, or visual modules, and may affect rendering only through the resolver-owned `State.targetTuning` channel.
- `documents/` owns product and governance documentation.

## Deterministic State And Event Rules

- Playback time is derived only from `playOffset + (audioContext.currentTime - playStartTime)`.
- Beat event consumption must be index-based and must reset explicitly on load, play, seek, stop, and end.
- Worker results may be applied only if they match the current load request id.
- State transitions must occur in this order when loading a new file: stop old playback, invalidate old worker/result, decode, analyze, publish result, enable UI.
- Shared state writes must have a single documented owner per field or a documented handoff between owners.
- Renderer code may consume playback state but must not initiate playback lifecycle decisions.
- UI code may request playback actions but must not compute audio analysis or mutate worker result payloads.

## Realtime Audio Safety Rules

- Do not use `p5.sound` for playback.
- Do not perform realtime FFT, beat detection, or spectral analysis inside p5 `draw()`.
- Do not allocate unbounded objects or run async work inside `draw()`.
- Do not create `Particle` instances during normal rendering; the particle pool is initialized once.
- `AudioBufferSourceNode` is one-shot. Play, pause, resume, and seek must create a fresh source and disconnect the previous source.
- Before manually stopping a source, set `source.onended = null`, then stop and disconnect.
- Audio data sent to workers must use an explicit copy-vs-transfer decision. Never accidentally detach data still needed by playback.

## Worker Communication Rules

- Worker messages must be typed at the boundary.
- Worker output must be treated as immutable by renderer and UI code.
- Every analysis request must be identifiable so stale worker results cannot overwrite newer state.
- Workers must terminate on success, error, cancellation, and superseded load.
- Worker output must be deterministic for the same input samples, sample rate, and algorithm version.
- Schema changes to worker input or output require single-agent ownership and validation across audio, state, renderer, and UI consumers.

## Task Decomposition

Decompose tasks by subsystem ownership first, then by file. Every task must identify affected owners: audio, worker, state, visuals, UI, docs, or build.

Safe to parallelize:

- Documentation-only edits in separate governance or product docs, with one integration owner checking consistency.
- Visual styling changes isolated to `src/style.css` when no DOM ids/classes are renamed.
- Renderer visual tuning that does not touch event consumption, audio timing, or shared state shape.
- Worker algorithm research or profiling when no schema or playback integration changes are made.
- Product documentation cleanup separate from code changes.

Single-agent ownership required:

- `AudioEngine` playback lifecycle, source-node handling, seek/play/pause/end behavior.
- Worker message schema and request-id race prevention.
- Shared `State` shape and mutation semantics.
- Cross-module refactors that change imports or ownership boundaries.
- Any change that alters event ordering between UI, audio, worker, state, and renderer.
- Dependency upgrades affecting Vite, TypeScript, p5, Web Audio assumptions, or worker bundling.

## Merge And Ownership Rules

- Each change must name the owner for each affected subsystem.
- Cross-boundary changes require one integration owner before merge.
- Do not mechanically merge parallel agent outputs. The integration owner must check duplicated rules, conflicting contracts, import boundary violations, stale docs, and broken validation.
- Updates to this file require checking every governance document for drift.
- `CLAUDE.md` must remain a thin adapter.

## Testing Gates

- Preserve cumulative regression coverage and reusable research code. Earlier active tests must run with new tests; reviewed replacements retain predecessor source/identity and reasons. Follow the retention and cumulative-run rules in [Testing and Validation](documents/governance/testing-validation.md). Never hide a failing test by deletion, exclusion, silent snapshot replacement, or rewriting its historical result.

- Any change touching `src/audio`, `src/audio/*.worker.ts`, `src/state`, event indexes, or playback timing requires a build plus targeted regression notes.
- Any visual-only change requires render smoke validation.
- Any worker algorithm change requires deterministic fixture-style validation where practical.
- Any governance-only change must verify references, inheritance, and absence of contradictory policy.
- Validation must start from the scripts declared in `package.json`. First inspect which runtime and package manager are available, then use the environment-compatible Node/npm command, normally `npm run build`, `npm test`, or `node --test <test-file>` for a targeted suite.
- If a required script is absent or broken, use `npx` or a local `node_modules/.bin`/package entrypoint with an available Node runtime. Do not install a dependency only to make validation runnable.
- Do not use a Bun-first strategy. Bun may be used only when environment discovery shows that it is the project's current, working runner and no suitable Node/npm/npx path is available.
- Before reporting completion, state the exact validation commands run, what could not be run, and every runtime or package-manager fallback used.

## Dependency Policy

- Keep runtime dependencies minimal.
- Do not add dependencies for simple state, timing, math, or DOM operations without an architecture justification.
- Dependency upgrades that affect Vite, TypeScript, p5, worker bundling, or Web Audio behavior require single-agent ownership and build validation.
- `src/types/` must not import runtime-heavy modules.

## Anti-Pattern Policy

The anti-pattern catalog is maintained in [Anti-Patterns](documents/governance/anti-patterns.md). If a change introduces one of those patterns, stop and redesign before implementation.
